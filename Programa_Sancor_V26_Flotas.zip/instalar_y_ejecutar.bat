@echo off
title Instalador Suite Sancor
echo Verificando dependencias...
pip install -r requirements.txt --quiet
echo Iniciando aplicacion...
python Sancor_Final_V26.py
pause
