import os
import pdfplumber
import fitz  # PyMuPDF
import pandas as pd
import customtkinter as ctk
from tkinter import filedialog, messagebox
from PIL import Image
import re
import math
import threading
import multiprocessing
import time
import gc
from datetime import datetime
from pathlib import Path

# Color corporativo de Sancor
SANCOR_COLOR = "#8A1538" 

ctk.set_appearance_mode("Dark")

def natural_sort_key(s):
    return [int(text) if text.isdigit() else text.lower() for text in re.split(r'(\d+)', str(s))]

def sanitize_name(s, max_len=120):
    s = "" if s is None or (isinstance(s, float) and math.isnan(s)) else str(s)
    s = re.sub(r'[\\/:*?"<>|\r\n\t]+', " ", s).strip()
    s = re.sub(r'\s+', " ", s)
    return s[:max_len] if len(s) > max_len else s

def clean_corredor_name(s):
    if pd.isna(s): return ""
    s = str(s)
    s = re.sub(r"\s*-\s*", " ", s).strip()
    return re.sub(r"\s+", " ", s)

def load_corredores(excel_path):
    if not excel_path: return {}
    try:
        if str(excel_path).lower().endswith('.csv'):
            raw = pd.read_csv(excel_path)
        else:
            raw = pd.read_excel(excel_path, sheet_name=0)
            
        num_col, name_col = None, None
        for c in raw.columns:
            c_low = str(c).lower()
            if "numero" in c_low or "número" in c_low or "nro" in c_low:
                num_col = c
            if "nombre" in c_low or "corredor" in c_low:
                if c != num_col:
                    name_col = c
        
        if not num_col or not name_col:
            num_col = raw.columns[0]
            name_col = raw.columns[1]
            
        def clean_num(x):
            if pd.isna(x): return ""
            try: return str(int(float(x)))
            except: return str(x).strip()
            
        return dict(zip(raw[num_col].apply(clean_num), raw[name_col].astype(str).apply(clean_corredor_name)))
    except Exception as e:
        print("Error leyendo excel:", e)
        return {}

def parse_layout(layout_text):
    clean = re.sub(r"\s+", " ", layout_text or "")
    m = re.search(r"\b(\d{5,8})\s+(\d{4,8})\s+\d+\s+(\d{7})\s+(\d{7})\s+(\d{9,12})\s+Desde:\s*(\d{1,2}/\d{1,2}/\d{4})", clean)
    ref, poliza, org, corredor, certificado, vig_desde = (None,)*6
    if m:
        ref, poliza, org, corredor, certificado, vig_desde = m.groups()
    else:
        m2 = re.search(r"\b(\d{5,8})\s+0\s+(\d{7})\s+(\d{7})\s+(\d{9,12})\s+Desde:\s*(\d{1,2}/\d{1,2}/\d{4})", clean)
        if m2:
            ref, org, corredor, certificado, vig_desde = m2.groups()
            poliza = "0"
            
    aseg_m = re.search(r"Sr\./es:\s*(.*?)\s+Cliente\s+n.:\s*([A-Z]\d{10,15})", clean, re.I)
    asegurado, id_asegurado = "", ""
    if aseg_m:
        asegurado = aseg_m.group(1).strip()
        id_asegurado = aseg_m.group(2).strip()
        
    return {
        "referencia": ref, "poliza": poliza, "org": org, "corredor": corredor,
        "certificado": certificado, "vig_desde": vig_desde, "asegurado": asegurado, "id_asegurado": id_asegurado
    }

def extract_asegurado_auto(text):
    m = re.search(r"Localidad:\s*([A-Z]\d{10,15})\s+([^\n]+)", text or "", re.S)
    if not m: return "", ""
    id_aseg = m.group(1).strip()
    raw = m.group(2).strip()
    best = None
    addr_tokens = [r"\bAv\.", r"\bAvenida\b", r"\bRambla\b", r"\bCalle\b", r"\bCamino\b", r"\bRuta\b"]
    for pat in addr_tokens:
        mm = re.search(pat, raw, re.I)
        if mm and mm.start() > 3:
            best = mm.start() if best is None else min(best, mm.start())
    name = raw[:best].strip() if best else raw
    name = re.split(r"\s+\*+\s+ASEGURADO\b", name)[0].strip()
    return id_aseg, name

def extract_page_data(p, fulltext):
    layout = p.crop((35, 110, 575, 220)).extract_text(x_tolerance=1, y_tolerance=3, layout=True) or ""
    data = parse_layout(layout)
    if not data["org"] or not data["corredor"]:
        mm = re.search(r"PROPUESTA\s+REFERENCIA\s+CERTIFICADO\s+ORG\s+CORREDOR\s+VIGENCIA\s+(\d+)\s+(\d{7})\s+(\d{7})\s+Desde", fulltext, re.S)
        if mm: data["org"], data["corredor"] = mm.groups()[1], mm.groups()[2]
    if not data["referencia"]:
        mm = re.search(r"(\d{5,8})\s*Aviso\s+de\s+Renovaci[oó]n", fulltext, re.I)
        if mm: data["referencia"] = mm.group(1)
    if not data["poliza"]:
        mm = re.search(r"POLIZA\s+NRO\.\s*(\d+)", fulltext, re.I)
        if mm: data["poliza"] = mm.group(1)
    if not data["asegurado"]:
        data["id_asegurado"], data["asegurado"] = extract_asegurado_auto(fulltext)
        
    m_ramo = re.search(r'\d{2}-0?(\d{3,4})20\d{2}', fulltext)
    data["ramo"] = m_ramo.group(1) if m_ramo else None
    if not data["ramo"]:
        m_ramo2 = re.search(r'\d{2}-0?(200|1800)\d{6,}', fulltext)
        data["ramo"] = m_ramo2.group(1) if m_ramo2 else None

    for k in ["referencia", "poliza", "org", "corredor", "asegurado", "ramo"]:
        if not data.get(k): data[k] = ""

    return data

def worker_extract_pdf(args):
    idx_pdf, pdf_path = args
    results = []
    try:
        with pdfplumber.open(str(pdf_path)) as pdf:
            for i, p in enumerate(pdf.pages):
                fulltext = p.extract_text() or ""
                data = extract_page_data(p, fulltext)
                is_cont = "Continúa de página anterior" in fulltext or "Continua de pagina anterior" in fulltext
                results.append({
                    "idx_pdf": idx_pdf,
                    "page_idx": i,
                    "data": data,
                    "is_cont": is_cont
                })
    except Exception as e:
        print(f"Error procesando {pdf_path}: {e}")
    return results

class SancorApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        
        self.title("Sancor Seguros - Suite V26 (Filtro Flotas > 3 hojas)")
        self.geometry("950x900")
        self.minsize(900, 800)
        self.configure(fg_color=SANCOR_COLOR)
        
        self.pdf_paths = []
        self.excel_maestro = ""
        self.excel_clausula = ""
        self.output_folder = ""
        self.opcion_var = ctk.IntVar(value=1)
        
        self.start_time = None
        self.timer_running = False
        self.current_progress = 0.0
        
        self.construir_interfaz()
        
    def construir_interfaz(self):
        header_frame = ctk.CTkFrame(self, fg_color="transparent")
        header_frame.pack(pady=(20, 10), fill="x")
        
        try:
            logo_img = ctk.CTkImage(light_image=Image.open("H_2006.png"), dark_image=Image.open("H_2006.png"), size=(250, 85))
            logo_label = ctk.CTkLabel(header_frame, image=logo_img, text="")
            logo_label.pack()
        except:
            title_label = ctk.CTkLabel(header_frame, text="SANCOR SEGUROS", font=ctk.CTkFont(size=24, weight="bold"), text_color="white")
            title_label.pack()
            
        self.main_frame = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.main_frame.pack(fill="both", expand=True, padx=20, pady=(0, 10))
        
        mid_frame = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        mid_frame.pack(fill="x", pady=5)
        mid_frame.grid_columnconfigure(0, weight=1)
        mid_frame.grid_columnconfigure(1, weight=1)
        
        files_frame = ctk.CTkFrame(mid_frame, fg_color="transparent", border_width=2, border_color="white", corner_radius=10)
        files_frame.grid(row=0, column=0, padx=(0, 10), sticky="nsew")
        
        ctk.CTkLabel(files_frame, text="Paso 1: Cargar Archivos", font=ctk.CTkFont(size=16, weight="bold"), text_color="white").pack(pady=(15, 10), anchor="w", padx=15)
        self.btn_pdfs = ctk.CTkButton(files_frame, text="Seleccionar PDFs a Separar", command=self.cargar_pdfs, fg_color="white", text_color=SANCOR_COLOR, font=ctk.CTkFont(weight="bold"))
        self.btn_pdfs.pack(pady=5, padx=20, fill="x")
        self.lbl_pdfs = ctk.CTkLabel(files_frame, text="No se han seleccionado PDFs.", text_color="#ffcccc")
        self.lbl_pdfs.pack(pady=(0, 10), padx=20, anchor="w")
        
        self.btn_exc_maestro = ctk.CTkButton(files_frame, text="Excel Corredores (Hoja 1 o CSV)", command=self.cargar_exc_maestro, fg_color="white", text_color=SANCOR_COLOR, font=ctk.CTkFont(weight="bold"))
        self.btn_exc_maestro.pack(pady=5, padx=20, fill="x")
        self.lbl_exc_maestro = ctk.CTkLabel(files_frame, text="Requerido para nombres.", text_color="#ffcccc")
        self.lbl_exc_maestro.pack(pady=(0, 10), padx=20, anchor="w")
        
        self.btn_exc_clausula = ctk.CTkButton(files_frame, text="Excel Opciones (Cláusula) [Opcional]", command=self.cargar_exc_clausula, fg_color="white", text_color=SANCOR_COLOR, font=ctk.CTkFont(weight="bold"))
        self.btn_exc_clausula.pack(pady=5, padx=20, fill="x")
        self.lbl_exc_clausula = ctk.CTkLabel(files_frame, text="Modo manual si no se carga.", text_color="#e0e0e0")
        self.lbl_exc_clausula.pack(pady=(0, 15), padx=20, anchor="w")
        
        options_frame = ctk.CTkFrame(mid_frame, fg_color="transparent", border_width=2, border_color="white", corner_radius=10)
        options_frame.grid(row=0, column=1, padx=(10, 0), sticky="nsew")
        
        ctk.CTkLabel(options_frame, text="Paso 2: Edición (Cláusula 350)", font=ctk.CTkFont(size=16, weight="bold"), text_color="white").pack(pady=(15, 10), anchor="w", padx=15)
        self.rb1 = ctk.CTkRadioButton(options_frame, text="Opción 1: Clausula de Renovación 350", variable=self.opcion_var, value=1, text_color="white", border_color="white", hover_color="#e0e0e0")
        self.rb1.pack(pady=5, padx=20, anchor="w")
        self.rb2 = ctk.CTkRadioButton(options_frame, text="Opción 2: Unidad con equipo instalado", variable=self.opcion_var, value=2, text_color="white", border_color="white", hover_color="#e0e0e0")
        self.rb2.pack(pady=5, padx=20, anchor="w")
        self.rb3 = ctk.CTkRadioButton(options_frame, text="Opción 3: Texto Personalizado", variable=self.opcion_var, value=3, text_color="white", border_color="white", hover_color="#e0e0e0")
        self.rb3.pack(pady=5, padx=20, anchor="w")
        self.rb4 = ctk.CTkRadioButton(options_frame, text="Opción 4: No editar (Solo Separar)", variable=self.opcion_var, value=4, text_color="white", border_color="white", hover_color="#e0e0e0")
        self.rb4.pack(pady=5, padx=20, anchor="w")
        
        self.txt_personalizado = ctk.CTkTextbox(options_frame, height=50, fg_color="transparent", border_color="white", border_width=1, text_color="white")
        self.txt_personalizado.pack(pady=(5, 15), padx=20, fill="x")
        
        out_frame = ctk.CTkFrame(self.main_frame, fg_color="transparent", border_width=2, border_color="white", corner_radius=10)
        out_frame.pack(pady=(15, 10), fill="x")
        
        ctk.CTkLabel(out_frame, text="Paso 3: Carpeta de Destino", font=ctk.CTkFont(size=16, weight="bold"), text_color="white").pack(pady=(10, 5), anchor="w", padx=15)
        out_inner = ctk.CTkFrame(out_frame, fg_color="transparent")
        out_inner.pack(fill="x", padx=15, pady=(0, 15))
        self.btn_out = ctk.CTkButton(out_inner, text="Seleccionar Carpeta", command=self.seleccionar_salida, fg_color="white", text_color=SANCOR_COLOR, font=ctk.CTkFont(weight="bold"), width=180)
        self.btn_out.pack(side="left", padx=(0, 10))
        self.lbl_out = ctk.CTkLabel(out_inner, text="Ninguna carpeta seleccionada", text_color="#ffcccc")
        self.lbl_out.pack(side="left", fill="x", expand=True, anchor="w")
        
        self.btn_procesar = ctk.CTkButton(self.main_frame, text="EJECUTAR PROCESO COMPLETO", font=ctk.CTkFont(size=18, weight="bold"), height=50, command=self.iniciar_proceso, fg_color="#4CAF50", text_color="white", hover_color="#45a049")
        self.btn_procesar.pack(pady=(10, 5), fill="x")
        
        self.progress = ctk.CTkProgressBar(self.main_frame, progress_color="white", fg_color="#b81e4b")
        self.progress.pack(fill="x", pady=5)
        self.progress.set(0)
        
        self.lbl_timer = ctk.CTkLabel(self.main_frame, text="⏳ Transcurrido: 00:00   |   ⏱️ Faltan: 00:00", text_color="#a3ffac", font=ctk.CTkFont(size=14, weight="bold"))
        self.lbl_timer.pack(pady=(5, 5))
        
        self.lbl_status = ctk.CTkLabel(self.main_frame, text="Listo para comenzar", text_color="white")
        self.lbl_status.pack()

    def cargar_pdfs(self):
        archivos = filedialog.askopenfilenames(title="Seleccionar PDFs", filetypes=[("Archivos PDF", "*.pdf")])
        if archivos:
            self.pdf_paths = sorted(list(archivos), key=lambda x: natural_sort_key(os.path.basename(x)))
            self.lbl_pdfs.configure(text=f"{len(self.pdf_paths)} archivo(s) seleccionado(s).", text_color="#a3ffac")
            
    def cargar_exc_maestro(self):
        archivo = filedialog.askopenfilename(title="Seleccionar Excel Corredores", filetypes=[("Archivos de Datos", "*.xlsx *.xls *.csv")])
        if archivo:
            self.excel_maestro = archivo
            self.lbl_exc_maestro.configure(text=f"Maestro: {os.path.basename(archivo)}", text_color="#a3ffac")
            
    def cargar_exc_clausula(self):
        archivo = filedialog.askopenfilename(title="Seleccionar Excel Cláusula", filetypes=[("Archivos Excel", "*.xlsx *.xls")])
        if archivo:
            self.excel_clausula = archivo
            self.lbl_exc_clausula.configure(text=f"Cláusula: {os.path.basename(archivo)}", text_color="#a3ffac")
            
    def seleccionar_salida(self):
        carpeta = filedialog.askdirectory(title="Seleccionar carpeta de salida")
        if carpeta:
            self.output_folder = carpeta
            self.lbl_out.configure(text=carpeta, text_color="#a3ffac")
            
    def obtener_texto_opcion(self, opcion):
        if opcion == 1:
            return ("A PARTIR DE LA RENOVACIÓN APLICA CLÁUSULA N° 350: EXCLUSION DE RAPIÑA O HURTO TOTAL - SISTEMA DE "
                    "RASTREO O LOCALIZACION DE VEHICULOS. Queda entendido y convenido que es requisito para la viabilidad "
                    "de esta cobertura de Rapiña o Hurto Total que la unidad asegurada en la presente póliza cuente con un "
                    "dispositivo de Rastreo y Localización de Vehículos provisto por Sancor Seguros Uruguay e instalado por "
                    "la empresa prestadora de servicios que a tal efecto designe esta Aseguradora. El asegurador queda "
                    "liberado si el asegurado no cumplió con el requisito señalado anteriormente, en un plazo de 25 días "
                    "corridos desde la emisión de la presente póliza, como consecuencia de operar la caducidad de los "
                    "derechos del Asegurado por incumplimiento de su carga.")
        elif opcion == 2:
            return "CLÁUSULA N° 350: ESTA UNIDAD CUENTA CON SISTEMA DE RASTREO O LOCALIZACION DE VEHICULOS"
        elif opcion == 3:
            return self.txt_personalizado.get("1.0", "end-1c")
        return ""

    def actualizar_progreso(self, val, msg):
        self.current_progress = val
        self.progress.set(val)
        self.lbl_status.configure(text=msg)

    def actualizar_cronometro(self):
        if self.timer_running and self.start_time:
            elapsed = int(time.time() - self.start_time)
            mins_t = elapsed // 60
            secs_t = elapsed % 60
            
            texto_base = f"⏳ Transcurrido: {mins_t:02d}:{secs_t:02d}"
            
            if self.current_progress > 0.005: 
                total_estimado = elapsed / self.current_progress
                restante = max(0, int(total_estimado - elapsed))
                mins_r = restante // 60
                secs_r = restante % 60
                texto_completo = f"{texto_base}   |   ⏱️ Faltan: {mins_r:02d}:{secs_r:02d} aprox"
            else:
                texto_completo = f"{texto_base}   |   ⏱️ Faltan: Calculando..."
                
            self.lbl_timer.configure(text=texto_completo)
            self.after(1000, self.actualizar_cronometro)

    def iniciar_proceso(self):
        if not self.pdf_paths:
            messagebox.showerror("Error", "Selecciona al menos un archivo PDF.")
            return
        if not self.output_folder:
            messagebox.showerror("Error", "Selecciona una carpeta de destino.")
            return
            
        self.btn_procesar.configure(state="disabled", text="PROCESANDO (Clasificador de Flotas)...")
        
        self.current_progress = 0.0
        self.start_time = time.time()
        self.timer_running = True
        self.actualizar_cronometro()
        
        threading.Thread(target=self.ejecutar_pipeline, daemon=True).start()

    def ejecutar_pipeline(self):
        try:
            map_corredores = load_corredores(self.excel_maestro)
            
            clausulas_dict = None
            if self.excel_clausula:
                try:
                    df_clausula = pd.read_excel(self.excel_clausula)
                    df_clausula.columns = [str(c).lower().replace('ó', 'o').strip() for c in df_clausula.columns]
                    clausulas_dict = {}
                    for _, row in df_clausula.iterrows():
                        r = str(row.get('referencia', '')).strip().replace('.0', '')
                        o = str(row.get('opcion', '')).strip().replace('.0', '')
                        if r and o in ['1', '2', '3', '4']:
                            clausulas_dict[r] = int(o)
                except Exception as e:
                    print("Error cargando clausulas:", e)

            records = []
            total_pdfs = len(self.pdf_paths)
            
            CHUNK_SIZE = 100 
            lotes = [self.pdf_paths[i:i + CHUNK_SIZE] for i in range(0, total_pdfs, CHUNK_SIZE)]
            total_lotes = len(lotes)
            
            archivos_procesados_global = 0
            
            max_w = min(3, max(1, os.cpu_count() - 1))
            
            for num_lote, lote_paths in enumerate(lotes):
                msg_lote = f"Lote {num_lote+1}/{total_lotes}"
                all_pages_extracted = []
                
                with multiprocessing.Pool(processes=max_w, maxtasksperchild=5) as pool:
                    pdf_inputs = [(i, path) for i, path in enumerate(lote_paths)]
                    
                    for res_pages in pool.imap_unordered(worker_extract_pdf, pdf_inputs):
                        all_pages_extracted.extend(res_pages)
                        archivos_procesados_global += 1
                        
                        progreso_extraccion = (archivos_procesados_global / total_pdfs) * 0.50
                        
                        if archivos_procesados_global % 5 == 0 or archivos_procesados_global == total_pdfs:
                            self.after(0, self.actualizar_progreso, progreso_extraccion, f"Leyendo y Extrayendo: {archivos_procesados_global}/{total_pdfs} archivos")

                all_pages_extracted.sort(key=lambda x: (x["idx_pdf"], x["page_idx"]))

                global_groups = {} 
                ref_to_key = {}
                pol_to_key = {}
                
                last_key = None
                for p_info in all_pages_extracted:
                    idx_pdf = p_info["idx_pdf"]
                    page_idx = p_info["page_idx"]
                    data = p_info["data"]
                    is_cont = p_info["is_cont"]
                    
                    ref = data["referencia"]
                    pol = data["poliza"]
                    current_key = None
                    
                    if (is_cont or (not ref and not pol)) and last_key:
                        current_key = last_key
                    elif not ref and not pol:
                        current_key = (f"SIN_REF_{idx_pdf}_{page_idx}", f"SIN_POL_{idx_pdf}_{page_idx}")
                    else:
                        k_ref = ref_to_key.get(ref) if ref else None
                        k_pol = pol_to_key.get(pol) if pol and pol != "0" else None
                        
                        if k_ref and k_pol and k_ref != k_pol:
                            global_groups[k_ref]["pages"].extend(global_groups[k_pol]["pages"])
                            for p_idx_pdf, p_page_idx, p_data in global_groups[k_pol]["pages"]:
                                if p_data["referencia"]: ref_to_key[p_data["referencia"]] = k_ref
                                if p_data["poliza"] and p_data["poliza"] != "0": pol_to_key[p_data["poliza"]] = k_ref
                            del global_groups[k_pol]
                            current_key = k_ref
                        elif k_ref:
                            current_key = k_ref
                        elif k_pol:
                            current_key = k_pol
                        else:
                            current_key = (ref, pol)
                            
                        if ref: ref_to_key[ref] = current_key
                        if pol and pol != "0": pol_to_key[pol] = current_key
                        
                    if current_key not in global_groups:
                        global_groups[current_key] = {"metadata": data, "pages": []}
                        
                    global_groups[current_key]["pages"].append((idx_pdf, page_idx, data))
                    last_key = current_key

                grupos_validos = list(global_groups.values())
                total_grupos_lote = len(grupos_validos)

                current_pdf_idx = None
                source_doc = None
                
                for num_g, group_info in enumerate(grupos_validos):
                    
                    if num_g % max(1, total_grupos_lote // 20) == 0 or num_g == total_grupos_lote - 1:
                        progreso_base = 0.50 + (num_lote / total_lotes) * 0.48
                        progreso_extra = (num_g / total_grupos_lote) * (0.48 / total_lotes)
                        self.after(0, self.actualizar_progreso, progreso_base + progreso_extra, f"Guardando {msg_lote} - Doc {num_g+1}/{total_grupos_lote}")
                    
                    g_data = group_info["metadata"]
                    ramo = g_data.get("ramo") or "SIN_RAMO"
                    org = g_data.get("org") or "ORG_SIN_DATO"
                    corredor = g_data.get("corredor") or "CORREDOR_SIN_DATO"
                    
                    ref = "S-REF"
                    poliza = "S-POL"
                    for _, _, p_data in group_info["pages"]:
                        if p_data["referencia"]: ref = p_data["referencia"]
                        if p_data["poliza"] and p_data["poliza"] != "0": poliza = p_data["poliza"]
                        
                    asegurado = g_data.get("asegurado") or "S-ASEG"
                    
                    corr_name = map_corredores.get(str(corredor), "SIN NOMBRE")
                    if corr_name == "SIN NOMBRE" and corredor:
                        try: corr_name = map_corredores.get(str(int(float(corredor))), "SIN NOMBRE")
                        except: pass
                    
                    first_pdf_idx = group_info["pages"][0][0]
                    base_name = os.path.splitext(os.path.basename(lote_paths[first_pdf_idx]))[0]
                    
                    numeros_en_nombre = re.findall(r'\d+', base_name)
                    num_archivo = ""
                    for n in numeros_en_nombre:
                        if n != str(ramo):
                            num_archivo = n
                            break
                    if not num_archivo: num_archivo = base_name
                        
                    nombre_carpeta_ramo = sanitize_name(f"Ramo {ramo}_{num_archivo}", 80)
                    nombre_carpeta_org = sanitize_name(f"ORG {org}", 80)
                    nombre_carpeta_corredor = sanitize_name(f"{corredor} {corr_name}", 140)
                    
                    # --- MEJORA V26: CLASIFICACIÓN DE FLOTAS (> 3 páginas) ---
                    cantidad_paginas = len(group_info["pages"])
                    es_flota = cantidad_paginas > 3
                    
                    if es_flota:
                        # Lo manda a una carpeta especial "Flotas" y mantiene la misma estructura adentro
                        folder = Path(self.output_folder) / "Flotas" / nombre_carpeta_ramo / nombre_carpeta_org / nombre_carpeta_corredor
                    else:
                        # Ruta normal para individuales
                        folder = Path(self.output_folder) / nombre_carpeta_ramo / nombre_carpeta_org / nombre_carpeta_corredor
                        
                    folder.mkdir(parents=True, exist_ok=True)
                    
                    nombre_archivo = sanitize_name(f"REF {ref} POLIZA {poliza} ASEGURADO {asegurado}.pdf", 180)
                    out_pdf = folder / nombre_archivo
                    
                    if out_pdf.exists():
                        records.append({
                            "Ramo": f"{ramo}_{num_archivo}", "ORG": org, "Corredor": corredor,
                            "Nombre Corredor": corr_name, "REF": ref, "POLIZA": poliza,
                            "ASEGURADO": asegurado, "Total Páginas": cantidad_paginas,
                            "Estado": "OMITIDO (Ya existía)" + (" (FLOTA)" if es_flota else "")
                        })
                        continue
                    
                    new_doc = fitz.open()
                    
                    for idx_pdf, page_idx, page_data in group_info["pages"]:
                        if current_pdf_idx != idx_pdf:
                            if source_doc: source_doc.close()
                            source_doc = fitz.open(lote_paths[idx_pdf])
                            current_pdf_idx = idx_pdf
                            
                        page = source_doc[page_idx]
                        ref_pagina = page_data["referencia"] or ref
                        
                        if clausulas_dict is not None:
                            opcion_aplicar = 4 
                            if ref_pagina and ref_pagina != "S-REF":
                                ref_busqueda = str(ref_pagina).strip()
                                if ref_busqueda in clausulas_dict:
                                    opcion_aplicar = clausulas_dict[ref_busqueda]
                        else:
                            opcion_aplicar = self.opcion_var.get()
                            
                        if opcion_aplicar in [1, 2, 3]:
                            texto_insertar = self.obtener_texto_opcion(opcion_aplicar)
                            obs_rects = page.search_for("Observaciones")
                            cuotas_rects = page.search_for("Cantidad de Cuotas")
                            
                            if obs_rects and cuotas_rects:
                                obs_r = obs_rects[0]
                                cuotas_validas = [r for r in cuotas_rects if r.y0 > obs_r.y1]
                                if cuotas_validas:
                                    cuotas_r = cuotas_validas[0]
                                    y_start = obs_r.y1 + 2
                                    y_end = cuotas_r.y0 - 2
                                    
                                    rect_fondo = fitz.Rect(obs_r.x0, y_start, page.rect.width - 30, y_end)
                                    page.draw_rect(rect_fondo, color=(1,1,1), fill=(1,1,1))
                                    
                                    rect_caja = fitz.Rect(obs_r.x0, y_start + 4, page.rect.width - 40, y_end - 4)
                                    page.draw_rect(rect_caja, color=(0,0,0), width=0.5)
                                    
                                    rect_texto = rect_caja + (4, 4, -4, -4)
                                    current_font = 8 if opcion_aplicar != 1 else 7.5
                                    while current_font > 4:
                                        rc = page.insert_textbox(rect_texto, texto_insertar, fontsize=current_font, fontname="hebo", align=3)
                                        if rc >= 0: break
                                        page.draw_rect(rect_texto, color=(1,1,1), fill=(1,1,1))
                                        current_font -= 0.5
                                        
                        new_doc.insert_pdf(source_doc, from_page=page_idx, to_page=page_idx)

                    new_doc.save(str(out_pdf))
                    new_doc.close()
                    
                    records.append({
                        "Ramo": f"{ramo}_{num_archivo}", "ORG": org, "Corredor": corredor,
                        "Nombre Corredor": corr_name, "REF": ref, "POLIZA": poliza,
                        "ASEGURADO": asegurado, "Total Páginas": cantidad_paginas,
                        "Estado": "Guardado Exitosamente" + (" (FLOTA)" if es_flota else "")
                    })

                if source_doc: source_doc.close()
                
                del all_pages_extracted
                del global_groups
                gc.collect()

            self.after(0, self.actualizar_progreso, 0.98, "Generando Excel de Resumen...")
            if records:
                df_resumen = pd.DataFrame(records)
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                nombre_excel = f"Resumen_Detallado_{timestamp}.xlsx"
                resumen_path = Path(self.output_folder) / nombre_excel
                df_resumen.to_excel(resumen_path, index=False)

            self.timer_running = False
            total_elapsed = int(time.time() - self.start_time)
            m_fin = total_elapsed // 60
            s_fin = total_elapsed % 60
            tiempo_final_str = f"{m_fin} min {s_fin} seg" if m_fin > 0 else f"{s_fin} segundos"

            self.after(0, lambda: messagebox.showinfo("Éxito", f"Proceso completado al 100%.\n\n⏱️ Tiempo total de procesamiento:\n{tiempo_final_str}\n\nSe generó el archivo: {nombre_excel}"))
            self.after(0, self.resetear_interfaz)
            
        except Exception as e:
            self.timer_running = False
            import traceback
            error_msg = traceback.format_exc()
            print(error_msg)
            self.after(0, lambda err=str(e): messagebox.showerror("Error Crítico", f"Ocurrió un error:\n{err}\n\nRevisa la consola."))
        finally:
            self.after(0, lambda: self.btn_procesar.configure(state="normal", text="EJECUTAR PROCESO COMPLETO"))

    def resetear_interfaz(self):
        self.pdf_paths = []
        self.lbl_pdfs.configure(text="No se han seleccionado PDFs.", text_color="#ffcccc")
        self.opcion_var.set(1)
        self.txt_personalizado.delete("1.0", "end")
        self.progress.set(0)
        self.current_progress = 0.0
        self.lbl_status.configure(text="Listo para procesar el siguiente lote.")
        self.lbl_timer.configure(text="⏳ Transcurrido: 00:00   |   ⏱️ Faltan: 00:00")

if __name__ == "__main__":
    multiprocessing.freeze_support()
    app = SancorApp()
    app.mainloop()
